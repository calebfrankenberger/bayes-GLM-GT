################################
# Simulator.R                  #
# Author: Caleb Frankenberger  #
################################

library(parallel)

#########################
## SIMULATE            ##
#########################
simulate <- function(N, beta_true, psz, Se.t, Sp.t, assayId,
                     postGit, burn, model_name, alpha=0.05, known_acc) {
  x1 <- rnorm(N, 0, 1)
  x2 <- rbinom(N, 1, 0.5)
  
  if (model_name == "M1") {
    X <- cbind(1, x1)
  } else if (model_name == "M2") {
    X <- cbind(1, x1, x2)
  } else if (model_name == "M3") {
    X <- cbind(1, x1, x1^2)
  }
  
  p.t <- g(X %*% beta_true)
  
  out   <- hier.gt.simulation(N = N, p = p.t,
                              S = length(psz),
                              psz = psz,
                              Se = Se.t, Sp = Sp.t,
                              assayID = assayId)
  gtOut <- out$gtData           
  Z     <- gtOut          
  tsts <- out$testsExp
  
  beta0 <- rep(0, length(beta_true))
  res <- bayes_reg(
    param0 = beta0,
    Z = Z,
    X = X,
    N = N,
    S = length(psz),
    g = g,
    postGit = postGit,
    known_acc = known_acc
  )

  post_samp <- res$param[-(1:burn),, drop=FALSE]
  post_means <- colMeans(post_samp)
  post_sds <- apply(post_samp, 2, sd)
  
  P <- length(beta_true)
  cred_int <- vector("list", P)
  for(j in 1:P) {
    cred_int[[j]] <- quantile(post_samp[, j], probs = c(alpha/2, 1 - alpha/2))
  }
  
  extra_out <- list()
  if(!known_acc) {
    extra_out$Se <- res$Se[-(1:burn),, drop=FALSE]
    extra_out$Sp <- res$Sp[-(1:burn),, drop=FALSE]
  }
  
  return(c(
  list(
    beta_mean = post_means,
    beta_sd   = post_sds,
    tests     = tsts,
    cred_int  = cred_int
  ),
  extra_out))
}

#######################
## RUN REPLICATES    ##
#######################
run_replicates <- function(nsim, N, beta_true, psz, Se.t, Sp.t, assayId,
                           postGit, burn, model_name, alpha=0.05, known_acc) {
  P <- length(beta_true)
  
  cores <- parallel::detectCores(logical=TRUE)
  cl <- parallel::makeCluster(cores)
  
  parallel::clusterEvalQ(cl, {
    dyn.load("gibbs_bayes.dll")
  })
  
  parallel::clusterExport(cl, varlist = c("simulate", "N", "beta_true", "psz", "Se.t", "Sp.t", "assayId", "postGit",
                                            "burn", "model_name", "alpha", "g", "known_acc",
                                            "bayes_reg", "hier.gt.simulation",
                                            "wls.mh.alg", "mt.ct"),
                          envir = environment())
  
  
  sim_list <- parallel::parLapplyLB(cl, 1:nsim, function(i) {
    simulate(N, beta_true, psz, Se.t, Sp.t, assayId,
             postGit, burn, model_name, alpha, known_acc)
  })
  
  parallel::stopCluster(cl)
  
  beta_means_mat <- t(sapply(sim_list, function(s) s$beta_mean))
  beta_sds_mat   <- t(sapply(sim_list, function(s) s$beta_sd))
  tests_vec      <- sapply(sim_list, function(s) s$tests)
  cred_ints      <- lapply(sim_list, function(s) s$cred_int)
  
  out <- list(
    beta_means = beta_means_mat,
    beta_sds   = beta_sds_mat,
    tests      = tests_vec,
    cred_ints  = cred_ints
  )
  
  # Add Se/Sp if present
  if (!known_acc) {
    out$Se_samps <- lapply(sim_list, `[[`, "Se")
    out$Sp_samps <- lapply(sim_list, `[[`, "Sp")
  }
  
  return(out)
}

#######################
## SUMMARIZE RESULTS ##
#######################
summarize_results <- function(results, beta_true, Se.t=NULL, Sp.t=NULL) {
  beta_means <- results$beta_means
  beta_sds   <- results$beta_sds
  tests      <- results$tests
  cred_ints  <- results$cred_ints
  beta_est <- colMeans(beta_means)
  bias <- beta_est - beta_true
  ssd <- apply(beta_means, 2, sd)
  ese <- colMeans(beta_sds)
  avg_tests <- mean(tests)
  
  P <- length(beta_true)
  nsim <- nrow(beta_means)
  cp <- numeric(P)
  for (j in 1:P) { 
    indicators <- numeric(nsim)
    for (i in 1:nsim) { 

      if (!is.null(cred_ints[[i]]) && length(cred_ints[[i]]) >= j) {
        current_ci_for_param_j <- cred_ints[[i]][[j]] 
        if (is.numeric(current_ci_for_param_j) && length(current_ci_for_param_j) == 2 && all(!is.na(current_ci_for_param_j))) {
          indicators[i] <- beta_true[j] >= current_ci_for_param_j[1] && beta_true[j] <= current_ci_for_param_j[2]
        } else {
          indicators[i] <- NA
        }
      } else {
        indicators[i] <- NA 
      }
    }
    cp[j] <- mean(indicators, na.rm = TRUE)
  }

  df_par <- data.frame(
    Parameter   = paste0("beta", seq_along(beta_true) - 1),
    TrueValue   = beta_true,
    EstMean     = beta_est,
    Bias        = bias,
    CP          = cp,
    SSD         = ssd,
    AvgPostSD   = ese,
    stringsAsFactors = FALSE
  )
  
  output <- list(
    param_summary = df_par,
    avg_tests     = avg_tests
  )
  
  if (!is.null(results$Se_samps) && !is.null(results$Sp_samps) &&
      !is.null(Se.t) && !is.null(Sp.t)) {
    
    se_means <- do.call(rbind, lapply(results$Se_samps, colMeans))
    sp_means <- do.call(rbind, lapply(results$Sp_samps, colMeans))
    
    se_post_mean <- colMeans(se_means)
    sp_post_mean <- colMeans(sp_means)
    se_bias <- se_post_mean - Se.t
    sp_bias <- sp_post_mean - Sp.t
    se_sd <- apply(se_means, 2, sd)
    sp_sd <- apply(sp_means, 2, sd)
    
    acc_summary <- data.frame(
      Assay = seq_along(Se.t),
      True_Se = Se.t,
      Est_Se = se_post_mean,
      Bias_Se = se_bias,
      SSD_Se = se_sd,
      True_Sp = Sp.t,
      Est_Sp = sp_post_mean,
      Bias_Sp = sp_bias,
      SSD_Sp = sp_sd
    )
    
    output$Se_summary <- se_post_mean
    output$Sp_summary <- sp_post_mean
    output$acc_summary <- acc_summary
  }
  
  return(output)
}

#######################
## PRINT RESULTS     ##
#######################
print_results <- function(summary, N, model_name) {
  cat("=====================================\n")
  cat("Model:", model_name, "\n")
  cat("=====================================\n\n")
  
  df <- summary$param_summary
  for (i in 1:nrow(df)) {
    cat("Parameter:", df$Parameter[i], "\n")
    cat("  True Value     :", df$TrueValue[i], "\n")
    cat("  Bias           :", round(df$Bias[i], 4), "\n")
    cat("  CP95           :", round(df$CP[i], 4), "\n")
    cat("  SSD            :", round(df$SSD[i], 4), "\n")
    cat("  ESE            :", round(df$AvgPostSD[i], 4), "\n")
    cat("-------------------------------------\n")
  }
  
  avg_tests <- summary$avg_tests
  pct_reduction <- round(100 * (1 - avg_tests / N), 2)
  cat("Average # of tests :", round(avg_tests, 2))
  cat("(", pct_reduction, "%)\n")
  cat("=====================================\n")
  
  if (!is.null(summary$Se_summary) && !is.null(summary$Sp_summary)) {
    cat("Se:\n")
    for (i in seq_along(summary$Se_summary)) {
      cat(paste0("  Se_", i - 1, ": "), round(summary$Se_summary[i], 4), "\n")
    }
    cat("\nSp:\n")
    for (i in seq_along(summary$Sp_summary)) {
      cat(paste0("  Sp_", i - 1, ": "), round(summary$Sp_summary[i], 4), "\n")
    }
    cat("-------------------------------------\n")
  }
}