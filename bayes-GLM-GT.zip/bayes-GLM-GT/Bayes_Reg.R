###########################################
# Bayes_Reg.R                             #
# Originally written by Dr. Shamim Sarker # 
# Modified by Caleb Frankenberger         #
###########################################


########################################################
# Bayesian Regression Models (McMahan et al., 2017)   
# Assay Accuracy Parameters (Se & Sp): KNOWN          
# This code was written in 2020                       
########################################################

BayesReg_KnownAccr <- function(param0,Z,X,N,S,g,postGit,a=NULL,R=NULL){
  dyn.load("gibbs_bayes.dll")
  X <- as.matrix(X)
  beta0 <- param0
  Yt <- rbinom(N,1,apply(X%*%beta0,2,g))
  
  Z <- Z[order(Z[ ,5]), ]
  tmp <- Z[ ,-(1:5)]
  ytm <- matrix(-9,N,S)
  vec <- 1:nrow(tmp)
  for(d in 1:N){
    tid <- tmp==d
    store <- NULL
    for(i in 1:ncol(tmp)){
      store <- c(store,vec[tid[ ,i]])
    }
    ytm[d,1:length(store)] <- sort(store)
  }
  Ytmat <- cbind(Yt,rowSums(ytm>0),ytm)
  Ycol <- ncol(Ytmat)
  SeSp <- Z[ ,3:4]
  Z <- Z[ ,-(3:5)]
  Zrow <- nrow(Z)
  Zcol <- ncol(Z)
  
  # Start Gibbs sampling:
  accept <- rep(-9,postGit)
  beta.sv <- matrix(-9,postGit,length(beta0))
  for(s in 1:postGit){
    GI <- 1
    emburn <- 0
    pvec <- apply(X%*%beta0,2,g)
    U <- runif(N)
    V <- rep(0,N)
    
    
    # (a) Sampling individual true statuses:
    res <- .C("gibbs_bayes",
              as.double(pvec),
              as.integer(Ytmat),
              as.integer(Z),
              as.integer(N),
              as.double(SeSp),
              as.integer(Ycol),
              as.integer(Zrow),
              as.integer(Zcol),
              as.double(U))
    Ytmat <- matrix(res[[2]],N,Ycol)    
    
    
    # (b) Sampling reg coefficient vector, beta:
    out <- wls.mh.alg(b0=beta0,X=X,y=Ytmat[,1],a=a,R=R)
    beta0 <- out$param
    beta.sv[s, ] <- beta0
    
    # (c) Sampling Se & Sp from beta conditionals:
    # a.se?
    # Se <- rbeta(1, a.se, b.se)
    # Sp <- rbeta(1, a.sp, b.sp)
    # Se.sv[i] <- Se
    # Sp.sv[i] <- Sp
    
    # Tracking acceptance in the MH algorithm:
    accept[s] <- out$accept
    
    #print(s)
  }
  dyn.unload("gibbs_bayes.dll")
  
  list("param"=beta.sv,"convergence"=0,"accept"=accept)
}

############################################
# This weighted least square (WLS) Metropolis-
# Hastings (MH) algorithm works only with 
# "logit" link function.
#
wls.mh.alg <- function(b0,X,y,a,R){
  library(mnormt)
  library(matrixcalc)
  
  res <- mt.ct(b=b0,y=y,X=X,sig=0,a=a,R=R)
  Mb0 <- res$M
  Cb0 <- res$C
  Lb0 <- res$L
  sig <- res$s
  
  b.star <- as.vector(rmnorm(1,Mb0,Cb0))
  qb.star <- dmnorm(b.star,as.vector(Mb0),Cb0)
  
  res2 <- mt.ct(b=b.star,y=y,X=X,sig=sig,a=a,R=R) 
  Mb.star <- res2$M
  Cb.star <- res2$C
  Lb.star <- res2$L
  
  qb0 <- dmnorm(b0,as.vector(Mb.star),Cb.star)
  ratio.pi <- exp(Lb.star-Lb0)
  alpha <- min(1,max(0,((ratio.pi*qb0)/(qb.star))))
  accept <- rbinom(1,1,alpha)
  if(accept==1){b1 <- b.star}
  if(accept==0){b1 <- b0}
  return(list("param"=b1,"accept"=accept))
}

############################################
# Supporting program for the MH sampling 
# function 'wls.mh.alg()' based on WLS method.
# Works only with logit link fn.
#
mt.ct <- function(b,y,X,sig,a,R){
  P <- length(b)
  xb <- X%*%b
  
  p <- exp(xb)/(1+exp(xb))
  W <- p*(1-p)
  Yb <- xb*(p*(1-p))+(y-p)
  XWX <- t(X*matrix(W,ncol=P,nrow=length(W),byrow=FALSE))%*%X
  if(is.non.singular.matrix(XWX)==FALSE || sig==1){
    XWX <- XWX+0.1*diag(rep(1,P))
    sig <- 1
  }
  
  if(is.null(R)){
    C <- solve(XWX)
    C <- (C+t(C))/2
    M <- C%*%(t(X)%*%(Yb))
    L <- sum(y*(xb)-log(1+exp(xb)))
  }else{
    R.inv <- solve(R)
    C <- solve(R.inv+XWX)
    C <- (C+t(C))/2
    M <- C%*%(R.inv%*%a+t(X)%*%(Yb))
    L <- (-1/2)*((b-a)%*%R.inv%*%(b-a))+sum(y*(xb)-log(1+exp(xb)))
  }
  return(list("M"=M, "C"=C, "L"=L, "s"=sig))
}
