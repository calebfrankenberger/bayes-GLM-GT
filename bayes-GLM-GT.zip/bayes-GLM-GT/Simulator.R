################################
# Simulator.R                  #
# Author: Caleb Frankenberger  #
################################

library(parallel)

#########################
## SIMULATE            ##
#########################
simulate <- function(N, beta_true, psz, Se.t, Sp.t, assayId,
                     postGit, burn, model_name, alpha=0.05) {
  x1 <- rnorm(N, 0, 1)
  x2 <- rbinom(N, 1, 0.5)
  
  if (model_name == "M1") {
    X <- cbind(1, x1)
  } else if (model_name == "M2") {
    X <- cbind(1, x1, x2)
  } else if (model_name == "M3") {
    X <- cbind(1, x1, x1^2)
  }
  
  p.t <- g(X %*% beta_true)
  
  out   <- hier.gt.simulation(N = N, p = p.t,
                              S = length(psz),
                              psz = psz,
                              Se = Se.t, Sp = Sp.t,
                              assayID = assayId)
  gtOut <- out$gtData           
  Z     <- gtOut          
  tsts <- out$testsExp
  
  beta0 <- rep(0, length(beta_true))
  res <- BayesReg_KnownAccr(param0 = beta0,
                            Z       = Z,
                            X       = X,
                            N       = N,
                            S       = length(psz),
                            g       = g,
                            postGit = postGit)
  post_samp <- res$param[-(1:burn),, drop=FALSE]
  post_means <- colMeans(post_samp)
  post_sds <- apply(post_samp, 2, sd)
  
  P <- length(beta_true)
  cred_int <- vector("list", P)
  for(j in 1:P) {
    cred_int[[j]] <- quantile(post_samp[, j], probs = c(alpha/2, 1 - alpha/2))
  }
  
  list(
    beta_mean = post_means,
    beta_sd   = post_sds,
    tests     = tsts,
    cred_int  = cred_int
  )
}

#######################
## RUN REPLICATES    ##
#######################
run_replicates <- function(nsim, N, beta_true, psz, Se.t, Sp.t, assayId,
                           postGit, burn, model_name, alpha=0.05) {
  P <- length(beta_true)
  
  cores <- parallel::detectCores(logical=TRUE)
  cl <- parallel::makeCluster(cores)
  
  parallel::clusterExport(cl, varlist = c("simulate", "N", "beta_true", "psz", "Se.t", "Sp.t", "assayId", "postGit",
                                            "burn", "model_name", "alpha", "g",
                                            "BayesReg_KnownAccr", "hier.gt.simulation",
                                            "wls.mh.alg", "mt.ct"),
                          envir = environment())
  
  
  sim_list <- parallel::parLapply(cl, 1:nsim, function(i) {
    simulate(N, beta_true, psz, Se.t, Sp.t, assayId,
             postGit, burn, model_name, alpha)
  })
  
  parallel::stopCluster(cl)
  
  beta_means_mat <- t(sapply(sim_list, function(s) s$beta_mean))
  beta_sds_mat   <- t(sapply(sim_list, function(s) s$beta_sd))
  tests_vec      <- sapply(sim_list, function(s) s$tests)
  cred_ints      <- lapply(sim_list, function(s) s$cred_int)
  
  list(
    beta_means = beta_means_mat,
    beta_sds   = beta_sds_mat,
    tests      = tests_vec,
    cred_ints  = cred_ints
  )
}

#######################
## SUMMARIZE RESULTS ##
#######################
summarize_results <- function(results, beta_true) {
  beta_means <- results$beta_means
  beta_sds   <- results$beta_sds
  tests      <- results$tests
  cred_ints  <- results$cred_ints
  beta_est <- colMeans(beta_means)
  bias <- beta_est - beta_true
  ssd <- apply(beta_means, 2, sd)
  ese <- colMeans(beta_sds)
  avg_tests <- mean(tests)
  
  P <- length(beta_true)
  nsim <- nrow(beta_means)
  cp <- numeric(P)
  for (j in 1:P) { 
    indicators <- numeric(nsim)
    for (i in 1:nsim) { 

      if (!is.null(cred_ints[[i]]) && length(cred_ints[[i]]) >= j) {
        current_ci_for_param_j <- cred_ints[[i]][[j]] 
        if (is.numeric(current_ci_for_param_j) && length(current_ci_for_param_j) == 2 && all(!is.na(current_ci_for_param_j))) {
          indicators[i] <- beta_true[j] >= current_ci_for_param_j[1] && beta_true[j] <= current_ci_for_param_j[2]
        } else {
          indicators[i] <- NA
        }
      } else {
        indicators[i] <- NA 
      }
    }
    cp[j] <- mean(indicators, na.rm = TRUE)
  }

  df_par <- data.frame(
    Parameter   = paste0("beta", seq_along(beta_true) - 1),
    TrueValue   = beta_true,
    EstMean     = beta_est,
    Bias        = bias,
    CP          = cp,
    SSD         = ssd,
    AvgPostSD   = ese,
    stringsAsFactors = FALSE
  )
  
  list(
    param_summary = df_par,
    avg_tests     = avg_tests
  )
}

#######################
## PRINT RESULTS     ##
#######################
print_results <- function(summary, N, model_name) {
  cat("=====================================\n")
  cat("Model:", model_name, "\n")
  cat("=====================================\n\n")
  
  df <- summary$param_summary
  for (i in 1:nrow(df)) {
    cat("Parameter:", df$Parameter[i], "\n")
    cat("  True Value     :", df$TrueValue[i], "\n")
    cat("  Bias           :", round(df$Bias[i], 4), "\n")
    cat("  CP95           :", round(df$CP[i], 4), "\n")
    cat("  SSD            :", round(df$SSD[i], 4), "\n")
    cat("  ESE            :", round(df$AvgPostSD[i], 4), "\n")
    cat("-------------------------------------\n")
  }
  
  avg_tests <- summary$avg_tests
  pct_reduction <- round(100 * (1 - avg_tests / N), 2)
  cat("Average # of tests :", round(avg_tests, 2))
  cat("(", pct_reduction, "%)\n")
  cat("=====================================\n")
}