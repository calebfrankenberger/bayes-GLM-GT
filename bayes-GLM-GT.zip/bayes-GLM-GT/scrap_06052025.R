set.seed(123)
N         <- 5000
model     <- "M2"
beta_true <- if (model=="M1") c(-3,2) else if (model=="M2") c(-3,2,-1) else c(-3,2,-0.5)
psz <- c(5, 1)
Se.t      <- rep(0.95, length(psz))
Sp.t      <- rep(0.98, length(psz))
assayId   <- rep(1, length(psz))

g <- function(t) exp(t)/(1 + exp(t))

nsim <- 500
postGit <- 6000
burn <- 1000
alpha <- 0.05

P <- length(beta_true)

x1 <- rnorm(N, 0, 1)
x2 <- rbinom(N, 1, 0.5)

if (model == "M1") {
  X <- cbind(1, x1)
} else if (model == "M2") {
  X <- cbind(1, x1, x2)
} else if (model == "M3") {
  X <- cbind(1, x1, x1^2)
}

p.t <- g(X %*% beta_true)

cat("---- Model:", model, "----\n")
cat("  mean(p.t) =", mean(p.t), "\n")
cat("------------------------------\n")

############################################
set.seed(123)
N         <- 5000
model     <- "M3"
beta_true <- if (model=="M1") c(-3,2) else if (model=="M2") c(-3,2,-1) else c(-3,2,-0.5)
psz <- c(5, 1)
Se.t      <- rep(0.95, length(psz))
Sp.t      <- rep(0.98, length(psz))
assayId   <- rep(1, length(psz))

g <- function(t) exp(t)/(1 + exp(t))

nsim <- 500
postGit <- 6000
burn <- 1000
alpha <- 0.05

P <- length(beta_true)

x1 <- rnorm(N, 0, 1)
x2 <- rbinom(N, 1, 0.5)

if (model == "M1") {
  X <- cbind(1, x1)
} else if (model == "M2") {
  X <- cbind(1, x1, x2)
} else if (model == "M3") {
  X <- cbind(1, x1, x1^2)
}

p.t <- g(X %*% beta_true)

cat("---- Model:", model, "----\n")
cat("  mean(p.t) =", mean(p.t), "\n")
cat("------------------------------\n")