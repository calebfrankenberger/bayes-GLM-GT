################################
# Run_Sim.R                    #
# Author: Caleb Frankenberger  #
################################

###########
## SETUP ##
###########
rm(list=ls())
setwd("C:/Users/caleb/Desktop/Research/bayes-GLM-GT")
library(mnormt)
library(matrixcalc)
library(groupTesting)
library(parallel)
source("Bayes_Reg.R")
source("Simulator.R")

###############
##  SETTINGS ##
###############
set.seed(123)
N         <- 5000
model     <- "M2"
beta_true <- if (model=="M1") c(-3,2) else if (model=="M2") c(-3,2,-1) else c(-3,2,-0.5)
psz <- c(5, 1)
Se.t      <- rep(0.95, length(psz))
Sp.t      <- rep(0.98, length(psz))
assayId   <- rep(1, length(psz))

g <- function(t) exp(t)/(1 + exp(t))

nsim <- 500
postGit <- 6000
burn <- 1000
alpha <- 0.05

##########################
##  RUNNING SIMULATION  ##
##########################
res <- run_replicates(
  nsim       = nsim,
  N          = N,
  beta_true  = beta_true,
  psz        = psz,
  Se.t       = Se.t,
  Sp.t       = Sp.t,
  assayId    = assayId,
  postGit    = postGit,
  burn       = burn,
  model_name = model,
  alpha      = alpha
)

summary <- summarize_results(res, beta_true)
print_results(summary, N, model)
