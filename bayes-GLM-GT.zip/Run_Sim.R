################################
# Run_Sim.R                    #
# Author: Caleb Frankenberger  #
################################

###########
## SETUP ##
###########
rm(list=ls())
setwd("C:/Users/caleb/Desktop/Research/bayes-GLM-GT")
library(mnormt)
library(matrixcalc)
library(groupTesting)
library(parallel)
source("Bayes_Reg.R")
source("MH_WLS.R")
source("Simulator.R")

###############
##  SETTINGS ##
###############
set.seed(123)
N         <- 5000
model     <- "M1"
beta_true <- if (model=="M1") c(-3,2) else if (model=="M2") c(-3,2,-1) else c(-3,2,-0.5)
psz <- c(5, 1)

# Se.t      <- rep(0.95, length(psz))
# Sp.t      <- rep(0.98, length(psz))
# assayId   <- rep(1, length(psz))
Se.t <- c(0.95, 0.98)
Sp.t <- c(0.98, 0.99)
assayId <- c(1, 2)
known_acc <- FALSE

g <- function(t) exp(t)/(1 + exp(t))

nsim <- 3
postGit <- 6000
burn <- 1000
alpha <- 0.05

##########################
##  RUNNING SIMULATION  ##
##########################
start_time <- Sys.time()
res <- run_replicates(
  nsim       = nsim,
  N          = N,
  beta_true  = beta_true,
  psz        = psz,
  Se.t       = Se.t,
  Sp.t       = Sp.t,
  assayId    = assayId,
  postGit    = postGit,
  burn       = burn,
  model_name = model,
  alpha      = alpha,
  known_acc  = known_acc
)
end_time <- Sys.time()

total_secs <- as.numeric(difftime(end_time, start_time, units = "secs"))
mins <- floor(total_secs / 60)
secs <- round(total_secs %% 60, 1)
cat(sprintf("\nTotal runtime: %d min %s sec\n\n", mins, secs))

summary <- summarize_results(res, beta_true, Se.t, Sp.t)
print_results(summary, N, model)
print(summary$acc_summary)
