###################################
# Bayes_Reg.R                     #
# Author: Caleb Frankenberger     #
###################################


bayes_reg <- function(param0, Z, X, N, S, g, postGit, a=NULL, R=NULL, known_acc=TRUE){
  X <- as.matrix(X)
  beta0 <- param0
  Yt <- rbinom(N, 1, apply(X %*% beta0, 2, g))
  #Yt <- rep(0L, N)
  
  # Sort and extract assay info
  Z <- Z[order(Z[,5]), ]
  assay_vec <- Z[, 5]
  unique_assays <- sort(unique(assay_vec))
  num_assays <- length(unique_assays)
  
  # Keep original Se/Sp for known_acc
  if (known_acc) {
    SeSp <- Z[, 3:4]
  } else {
    SeSp <- matrix(0.6, nrow(Z), 2)
  }
  
  # Construct Y-til matrix
  tmp <- Z[, -(1:5)]
  ytm <- matrix(-9L, N, S)
  for (d in 1:N) {
    idx <- which(tmp == d, arr.ind = TRUE)[, "row"]
    if (length(idx) > 0) {
      ytm[d, 1:length(idx)] <- sort(idx)
    }
  }
  Ytmat <- cbind(Yt, rowSums(ytm > 0), ytm)
  Ycol <- ncol(Ytmat)
  
  # Store necessary Z data 
  Z <- Z[ ,-(3:5)]
  Zrow <- nrow(Z)
  Zcol <- ncol(Z)
  
  accept <- rep(-9, postGit)
  beta.sv <- matrix(-9, postGit, length(beta0))
  
  if (!known_acc) {
    Se.sv <- matrix(NA, postGit, num_assays)
    Sp.sv <- matrix(NA, postGit, num_assays)
  }
  
  # Begin Gibbs sampling:
  for (s in 1:postGit) {
    pvec <- g(drop(X %*% beta0))
    U <- runif(N)
    
    # Sampling individual true statuses
    Ztil <- integer(Zrow * Zcol)
    res <- .C("gibbs_bayes",
              as.double(pvec),
              as.integer(Ytmat),
              as.integer(Z),
              as.integer(N),
              as.double(SeSp),
              as.integer(Ycol),
              as.integer(Zrow),
              as.integer(Zcol),
              as.double(U),
              Ztil = as.integer(Ztil))
    
    Ytmat <- matrix(res[[2]], N, Ycol)
    Ztil <- matrix(res$Ztil, Zrow, Zcol) 
    
    # Sampling beta
    out <- wls.mh.alg(b0 = beta0, X = X, y = Ytmat[, 1], a = a, R = R)
    beta0 <- out$param
    beta.sv[s, ] <- beta0
    
    # Sampling Se & Sp:
    if (!known_acc) {
      Ztest <- Z[, 1]         # Observed pool result
      Ztrue <- Ztil[, 1]      # True pool result
      
      Se <- Sp <- numeric(num_assays)
      a_se0 <- b_se0 <- a_sp0 <- b_sp0 <- 1 
      
      for (asy in seq_len(num_assays)) {
        idx <- assay_vec == unique_assays[asy]
        
        Zj <- Ztest[idx]
        Ztilj <- Ztrue[idx]
        
        a_se_star <- a_se0 + sum(Zj * Ztilj)
        b_se_star <- b_se0 + sum((1 - Zj) * Ztilj)
        
        a_sp_star <- a_sp0 + sum((1 - Zj) * (1 - Ztilj))
        b_sp_star <- b_sp0 + sum(Zj * (1 - Ztilj))
        
        Se[asy] <- rbeta(1, a_se_star, b_se_star)
        Sp[asy] <- rbeta(1, a_sp_star, b_sp_star)
      }
      
      Se.sv[s, ] <- Se
      Sp.sv[s, ] <- Sp
      
      SeSp <- cbind(
        Se[match(assay_vec, unique_assays)],
        Sp[match(assay_vec, unique_assays)]
      )
    }
    
    
    # Track acceptance in the MH algorithm:
    accept[s] <- out$accept
  }
  
  output <- list(param = beta.sv, convergence = 0, accept = accept)
  if (!known_acc) {
    colnames(Se.sv) <- paste0("Se_a", unique_assays)
    colnames(Sp.sv) <- paste0("Sp_a", unique_assays)
    output$Se <- Se.sv
    output$Sp <- Sp.sv
  }
  return(output)
}

